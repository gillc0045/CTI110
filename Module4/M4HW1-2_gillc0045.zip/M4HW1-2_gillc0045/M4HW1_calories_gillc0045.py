# Question M3Q2A-M
# Calvin Gill
# 13 Jun 2017
#
# Running on a particular treadmill you burn 4.2 calories per minute.
# This program displays the number of calories burned after 10, 15, 20, 25, and 30 minuutes.

